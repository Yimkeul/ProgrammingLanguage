let interp_def (def : Ast.fundef) (store : Fstore.t) : Fstore.t =
  match def with
  | Ast.FunDef (name, params, body) ->
      Fstore.add name params body store

let interp_expr ast fstore store =
  let rec interp_expr' (ast : Ast.expr) (fstore : Fstore.t) (store : Store.t) : Store.value =
    match ast with
    | Num n -> Store.NumV n
    | Id x -> Store.find x store
    | Add (e1, e2) ->
      let v1 = interp_expr' e1 fstore store in
      let v2 = interp_expr' e2 fstore store in
      (
        match (v1, v2) with
        | NumV v1, NumV v2 -> NumV (v1 + v2)
      )
    | Sub (e1, e2) ->
      let v1 = interp_expr' e1 fstore store in
      let v2 = interp_expr' e2 fstore store in
      (
        match (v1, v2) with
        | NumV v1, NumV v2 -> NumV (v1 - v2)
      )
    | LetIn (name, e1, e2) ->
      let value = interp_expr' e1 fstore store in
      let res = Store.add name value store in
      interp_expr' e2 fstore res
    | Call (name, args) ->
      (
        match Fstore.find name fstore with
        | (param_lst, expr) ->
          let rec tstore p_lst v_lst temp =
            match p_lst, v_lst with
            | [], [] -> temp
            | h1 :: t1, h2 :: t2 ->
              tstore t1 t2 (Store.add h1 (interp_expr' h2 fstore store) temp)
            | _, _ -> failwith "[Error] Unmatched the number of arguments"
          in let sigma1 = tstore param_lst args Store.empty
          in interp_expr' expr fstore sigma1
      )
  in interp_expr' ast fstore store  
let interp_prog (prog : Ast.prog) : Store.value =
  match prog with
  | Ast.Prog (fundefs, expr) ->
      let fstore = List.fold_left (fun acc def -> interp_def def acc) Fstore.empty fundefs in
      let store = Store.empty in
      interp_expr expr fstore store

      
